// lob/action/action.handler.ts
import type { Server, Socket } from "socket.io";
import { pool } from "../../db/db.ts";

import { gameStates } from "../game/gameState/gameState.ts";
import { handleAction } from "../game/flow/handleAction.ts";
import { buildSidePots } from "../game/pot/pots.ts";
import { emitPots } from "../emit/emitPots.ts";
import {emitTurn} from "../emit/emitTurn.ts";
import { emitFullPlayers } from "../emit/emitFullPlayers.ts";
import {
    resolveShowdown,
} from "../game/flow/resolveShowdown.ts";
import { endHandAndResetIfNeeded} from "../game/flow/endAndReset.ts";
import { validateAction } from "./action.validator.ts";
import { persistSaldoDiff } from "./action.transaction.ts";

import { startTurnTimer } from "../game/flow/turnTimer.ts";
import { isBettingRoundComplete } from "../game/flow/isBettingComplete.ts";
export async function handleMakeAction(
    io: Server,
    socket: Socket,
    { lobbyId, playerId, action, amount }
) {
    const state = gameStates.get(lobbyId);
    if (!state) return;
    const startTimerForCurrentTurn = () => {
        console.log("⏱️ START TIMER:", state.players[state.currentTurn]?.playerId);
        startTurnTimer(
            state,
            (playerId, timeLeft) => {
                io.to(`lobby_${lobbyId}`).emit("turnTimerUpdate", {
                    playerId,
                    timeLeft
                });
            },
            async (timeoutPlayerId) => {
                console.log("⏰ AUTO FOLD →", timeoutPlayerId);

                const current = state.players[state.currentTurn];
                if (!current || current.playerId !== timeoutPlayerId) return;

                // 🧹 bezpieczeństwo
                if (state.turnInterval) {
                    clearInterval(state.turnInterval);
                    state.turnInterval = null;
                }

                await handleMakeAction(io, socket, {
                    lobbyId,
                    playerId: timeoutPlayerId,
                    action: "fold"
                });
            }
        );
    };

    if (!validateAction(state, lobbyId, playerId)) return;

    const player = state.players.find(p => p.playerId === playerId);
    if (!player) return;

    const client = await pool.connect();

    let roundComplete = false;
    let saldoBefore = player.saldo;
    let saldoAfter = player.saldo;
    let diff = 0;
    let prevTurn = state.currentTurn;
    let newTurn = state.currentTurn;

    try {
        // ===============================
        // 🔐 START TRANSAKCJI
        // ===============================
        await client.query("BEGIN");

        console.log("🎯 ACTION_IN", {
            lobbyId,
            playerId,
            action,
            amount,
            saldo: player.saldo,
            bet: player.bet,
            committed: player.totalCommitted
        });

        // ===============================
        // 🎮 LOGIKA GRY (IN-MEMORY)
        // ===============================
        prevTurn = state.currentTurn;

        roundComplete = handleAction(state, playerId, action, amount);

        newTurn = state.currentTurn;

        saldoAfter = player.saldo;
        diff = saldoAfter - saldoBefore;

        console.log("🎯 ACTION_OUT", {
            playerId,
            action,
            saldoAfter: player.saldo,
            betAfter: player.bet,
            committedAfter: player.totalCommitted,
            allIn: player.allIn,
            folded: player.folded
        });

        // ===============================
        // 💾 PERSIST SALDO (DB)
        // ===============================
        if (diff !== 0) {
            await persistSaldoDiff(client, diff, playerId);
        }

        // ===============================
        // ✅ COMMIT
        // ===============================
        await client.query("COMMIT");
    } catch (err) {
        // ===============================
        // ❌ ROLLBACK
        // ===============================
        await client.query("ROLLBACK");

        console.error("🔥 ACTION FAILED – ROLLBACK", {
            lobbyId,
            playerId,
            action,
            amount,
            error: err
        });

        throw err;
    } finally {
        client.release();
    }
    //
    // =====================================================
    // 📡 EMITY — TYLKO PO COMMIT
    // =====================================================

    await emitFullPlayers(io, lobbyId);

    io.to(`lobby_${lobbyId}`).emit("playerUpdateBets", {
        players: state.players
    });

    emitTurn(io, lobbyId, state);
    // 🔥 START TIMER TYLKO JEŚLI ZMIENIŁA SIĘ TURA
    if (state.phase !== "showdown" && prevTurn !== newTurn) {
        startTimerForCurrentTurn();
    }
    // =====================================================
    // 🔁 KONIEC RUNDY LICYTACJI
    // =====================================================
    if (roundComplete) {
        buildSidePots(state);
        emitPots(io, lobbyId, state);

        io.to(`lobby_${lobbyId}`).emit("bettingRoundComplete", { lobbyId });
        io.to(`lobby_${lobbyId}`).emit("phaseUpdate", {
            phase: state.phase,
            communityCards: state.communityCards
        });
    }

    // =====================================================
    // 🏁 SHOWDOWN
    // =====================================================
    if (state.phase === "showdown") {
        await resolveShowdown(io, lobbyId, state);

        setTimeout(async () => {
            await endHandAndResetIfNeeded(io, lobbyId, state);
        }, 5000);
    }

}

