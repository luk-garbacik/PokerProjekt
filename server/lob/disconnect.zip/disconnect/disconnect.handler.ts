// disconnect.handler.ts
import { socketMeta } from "../infra/socketMeta.ts";
import { gameStates } from "../game/gameState/gameState.ts";
import { handleDisconnectInGame } from "./disconnect.game.ts";
import { disconnectTransaction } from "./disconnect.transaction.ts";
import { emitFullPlayers } from "../emit/emitFullPlayers.ts";
import { pool } from "../../db/db.ts";

export async function disconnectHandler(io, socket) {
    const meta = socketMeta.get(socket.id);
    if (!meta?.playerId) {
        socketMeta.delete(socket.id);
        return;
    }

    const playerId = meta.playerId;
    const lobbies = Array.from(meta.lobbies);
    socketMeta.delete(socket.id);

    for (const lobbyId of lobbies) {
        const client = await pool.connect();
        try {
            await client.query("BEGIN");

            const state = gameStates.get(lobbyId);
            if (state) {
                await handleDisconnectInGame(io, state, playerId, lobbyId);
            }

            await disconnectTransaction(client, lobbyId, playerId);

            await client.query("COMMIT");
        } catch (err) {
            await client.query("ROLLBACK");
            console.error("disconnect error", { lobbyId, playerId, err });
        } finally {
            client.release();
        }

        await emitFullPlayers(io, lobbyId);
    }
}

