import type { GameState } from "../../types/lobbyTypes.ts";

export function startTurnTimer(
    state: GameState,
    onTick: (playerId: number, timeLeft: number) => void,
    onTimeout: (playerId: number) => void
) {
    // 🧹 ZAWSZE czyść stary timer
    if (state.turnInterval) {
        clearInterval(state.turnInterval);
        state.turnInterval = null;
    }

    const turnIndex = state.currentTurn;
    const player = state.players[turnIndex];

    if (!player) return;
    if (player.folded || player.allIn) return;
    if (state.phase === "showdown") return;

    let timeLeft = 30;

    onTick(player.playerId, timeLeft);

    state.turnInterval = setInterval(() => {

        // 🔥 Jeżeli tura się zmieniła – zatrzymaj
        if (state.currentTurn !== turnIndex) {
            clearInterval(state.turnInterval!);
            state.turnInterval = null;
            return;
        }

        timeLeft--;
        onTick(player.playerId, timeLeft);

        if (timeLeft <= 0) {
            clearInterval(state.turnInterval!);
            state.turnInterval = null;

            onTimeout(player.playerId);
        }

    }, 1000);
}