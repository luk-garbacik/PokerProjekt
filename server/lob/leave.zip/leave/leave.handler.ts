// leave.handler.ts
import { pool } from "../../db/db.ts";
import { handleLeaveInGame } from "./leave.game.ts";
import { leaveLobbyTransaction } from "./leave.transaction.ts";
import { emitFullPlayers } from "../emit/emitFullPlayers.ts";
import { socketMeta } from "../infra/socketMeta.ts";
import { gameStates } from "../game/gameState/gameState.ts";

export async function leaveLobbyHandler(io, socket, payload) {
    const { lobbyId, playerId } = payload;
    const client = await pool.connect();
    const state = gameStates.get(lobbyId);

    try {
        await client.query("BEGIN");

        if (state) {
            await handleLeaveInGame(io, state, playerId, lobbyId);
        }

        await leaveLobbyTransaction(client, lobbyId, playerId);

        await client.query("COMMIT");

        socket.leave(`lobby_${lobbyId}`);
        socket.leave(`player_${playerId}`);

        const meta = socketMeta.get(socket.id);
        meta?.lobbies.delete(lobbyId);

        await emitFullPlayers(io, lobbyId);

    } catch (err) {
        await client.query("ROLLBACK").catch(() => {});
        console.error("leaveLobby error:", err);
        throw err;
    } finally {
        client.release();
    }
}


