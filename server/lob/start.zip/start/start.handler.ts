// start/start.handler.ts
import { pool } from "../../db/db.ts";
import { gameStates } from "../game/gameState/gameState.ts";
import { loadPlayersAndLobby } from "./start.transaction.ts";
import { buildInitialState } from "./start.state.ts";
import { applyBlindsIfPossible } from "./start.blinds.ts";
import { emitStartGame } from "./start.emit.ts";

export async function startGameHandler(io, socket, lobbyId: number) {
    const client = await pool.connect();

    try {
        const { players, smallBlind, bigBlind } =
            await loadPlayersAndLobby(client, lobbyId);

        const state = buildInitialState(
            lobbyId,
            players,
            smallBlind,
            bigBlind
        );

        await applyBlindsIfPossible(client, io, state);

        gameStates.set(lobbyId, state);

        emitStartGame(io, lobbyId, state);

        console.log(`🎴 Start gry w lobby ${lobbyId}`);
    } finally {
        client.release();
    }
}
